
import SwiftUI

@main
struct RentavelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
